import math
import numpy as np
import matplotlib.pyplot as plt


open_arr = np.loadtxt("openPrice.txt",delimiter= ",")
print("Open Price Numpy array is :\n",open_arr)
close_arr =  np.loadtxt("closePrice.txt",delimiter= ",")
print("\nClose Price Numpy array is :\n",close_arr)


dailyEarningNumpyArray = np.subtract(close_arr, open_arr)
print("\nCalculated daily earning numpy array is :\n",dailyEarningNumpyArray)

mean = np.mean(dailyEarningNumpyArray)
print("\nCalculated mean of daily Earnings is :\n",mean)

standardDeviation = np.std(dailyEarningNumpyArray)
print("\nCalculated standardDeviation of daily Earnings is :\n",standardDeviation)
print("\n\n")

for i in range(len(open_arr)):
    print("{} Standard Deviation of the mean is:{}".format(i+1,((i+1)*np.std(dailyEarningNumpyArray))+np.mean(dailyEarningNumpyArray)))


#Problem 2 start from here
def areaOfSquare_diagonal(d):
    area = d*d/2
    #area = 1*math.sqrt((d*d)-(1*1))
    return area
def find_parameter(d):
    area = 2*math.sqrt(2)*d
    #para = 2*1+2*math.sqrt((d*d)-(1*1))
    return area

x_cord = np.loadtxt("openPrice.txt",delimiter= ",")
y_cord = np.loadtxt("closePrice.txt",delimiter= ",")

diagList = []
paraList = []
for x in x_cord:
    for y in y_cord:

        distta = math.dist([float(x)],[float(y)])
        diagList.append(areaOfSquare_diagonal(distta))
for i in diagList:
    paraList.append(find_parameter(i))

plt.plot(x_cord, y_cord)

plt.show()


print("Largest area of rectangle is {}".format(max(diagList)))
print("Largest parameter of rectangle is {}".format(max(paraList)))