import pandas as pd
import warnings
import mlxtend
import sklearn

warnings.filterwarnings("ignore")
df = pd.read_csv("./data_banknote_authentication.csv",header=None)
df.columns =["variance_of_wavelet_transformed_image","skewness_of_wavelet_transformed_image","kurtosis_of_wavelet_transformed_image","entropy_of_image","target"]
df.head(30)
import seaborn as sns
from sklearn.ensemble import RandomForestRegressor
import matplotlib.pyplot as plt
import seaborn as sns

# %matplotlib inline
#correlation map
sns.heatmap(df.corr(), annot=True, linewidths=.5, fmt= '.1f')
plt.show()

# Print the correlation matrix
df.corr()
# Get feature importance scores for from random forest regressor
reg = RandomForestRegressor(n_estimators=50)
reg.fit(df.iloc[:,:-1], df.iloc[:,-1])
df_feature_importance = pd.DataFrame(reg.feature_importances_,index=df.columns[:-1], columns=['feature importance']).sort_values('feature importance', ascending=False)
# all feature importance for each tree
# Melted data i.e., long format
df_feature_all = pd.DataFrame([tree.feature_importances_ for tree in reg.estimators_], columns=df.columns[:-1])
df_feature_all.head()
df_feature_long = pd.melt(df_feature_all,var_name='feature name', value_name='values')
df_feature_importance.plot(kind='bar', title='Plots Comparison for Feature Importance');
plt.tight_layout()

# From feature importance scores and correlation map we can see that feature 4 is not correlate much with target and hence
# can be neglected for classification. Here feature_1,feature_2,feature_3 affect the most for classification
# Perceptron model
from sklearn.model_selection import train_test_split
X =df.iloc[:,:-2]
y = df["target"]
X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y,
                                                    random_state=1)

from mlxtend.classifier import Perceptron
from mlxtend.classifier import Adaline
import numpy as np

ppn = Perceptron(epochs=50, eta=0.05, random_seed=0)
ppn.fit(np.array(X_train), np.array(y_train))
ada = Adaline(epochs=50, eta=0.05, random_seed=0)
ada.fit(X_train, y_train)
print("The train accuracy score of perceptron ",ppn.score(X_train,y_train))
print("The train accuracy score of adaline ",ada.score(X_train,y_train))
print("The test accuracy score of perceptron ",ppn.score(X_test,y_test))
print("The test accuracy score of adaline ",ada.score(X_test,y_test))